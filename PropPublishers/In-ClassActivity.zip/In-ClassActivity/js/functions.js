/* complete the functions below */



function loadCart(){
	for (i=0;i<filenames.length;i++){
		outputCartRow(filenames[i], titles[i], quantities[i], prices[i], 100);
	}
	
}

function outputCartRow(file, title, quantity, price, total) {     
    document.write('<tr>');
    document.write('<td><img src="images//'+file+'"></td>');
    document.write('<td>'+title+'</td>');
    document.write('<td class="center">'+quantity+'</td>');
    document.write('<td class="right">$'+price.toFixed(2)+'</td>');
    document.write('<td class="right">$'+calculateTotal(quantity, price).toFixed(2)+'</td>');
    document.write('</tr>');      
}

function calculateTotal(quantity, price) {
	subtotal = subtotal+(quantity*price);
	return quantity*price;
}

function calculateTax(subtotal, rate) {
	var taxAmt = (subtotal*rate)/100;
	return taxAmt;
}

function calculateShipping(subtotal, threshold) {
	var shippingCost=0;
	if(subtotal>threshold){
		shippingCost = 40;
	}else{
		shippingCost = 0;
	}
	return shippingCost;
}

function calculateGrandTotal(subtotal,tax,shipping) {
     return 0;
}

function showSubTotal(){
	 document.write('$'+subtotal.toFixed(2));
}
function showTax(){
	tax = calculateTax(subtotal, tax_rate);
	document.write('$'+tax.toFixed(2));
}
function showShipping(){
	shipping = calculateShipping(subtotal, shipping_threshold);
	document.write('$'+shipping.toFixed(2));
}
function showGrandTotal(){
	grandTotal = subtotal+tax+shipping;
	 document.write('$'+grandTotal.toFixed(2));
}
        
