
var filenames = ["106020.jpg","116010.jpg","120010.jpg"];
var titles = ["Girl with a Pearl Earring","Artist Holding a Thistle","Portrait of Eleanor of Toledo"];
var quantities = [3,1,2];
var prices = [80,125,75];

       