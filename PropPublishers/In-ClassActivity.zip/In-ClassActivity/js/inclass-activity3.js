

var tax_rate = 10;
var shipping_threshold = 1000;
var subtotal = 0;
var product_total = 0;


var tax =0;
var shipping =0;
var grandTotal =0;

